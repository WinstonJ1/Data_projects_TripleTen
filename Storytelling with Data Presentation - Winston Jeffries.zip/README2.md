Link to complete Presentation
https://public.tableau.com/views/StorytellingwithDataProject-WinstonJeffries/Story-FullDetail?:language=en-US&publish=yes&:sid=&:display_count=n&:origin=viz_share_link
Link to Presentation with just Titles and Captions, no spreadsheets
https://public.tableau.com/views/StorytellingwithDataProject-WinstonJeffries-OnlyStoryCaptions/Story-OnlyCaptions?:language=en-US&publish=yes&:sid=&:display_count=n&:origin=viz_share_link
